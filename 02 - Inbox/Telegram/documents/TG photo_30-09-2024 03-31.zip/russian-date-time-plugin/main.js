const { Plugin } = require('obsidian');

// Функция для получения даты и времени в русском формате
function getFormattedDateTime() {
  const now = new Date();
  const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
  const formattedDate = now.toLocaleDateString('ru-RU', options).replace(/,\sг\./, ' г.');
  const formattedTime = now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  return `${formattedDate}, ${formattedTime}`;
}

// Создаем класс плагина
module.exports = class RussianDateTimePlugin extends Plugin {
  async onload() {
    console.log('Loading Russian DateTime plugin');
    
    // Регистрируем обработчик блока кода "date-time"
    this.registerMarkdownCodeBlockProcessor("date-time", (source, el, ctx) => {
      const updateDateTime = () => {
        const formattedDateTime = getFormattedDateTime();
        el.innerHTML = `<p>${formattedDateTime}</p>`;
      };
      
      updateDateTime(); // Обновление при загрузке

      // Запуск таймера для обновления каждую секунду
      const intervalId = setInterval(updateDateTime, 1000);

      // Убедимся, что таймер будет очищен при выгрузке элемента
      el.onunload = () => clearInterval(intervalId);
    });
  }

  onunload() {
    console.log('Unloading Russian DateTime plugin');
  }
};